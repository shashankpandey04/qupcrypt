# __init__.py
from .encryption import SimpleEncryptor
