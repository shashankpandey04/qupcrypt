# __init__.py
from .encryption import SimpleEncryptor
from .ext import CustomAES
from .WebCrypt import WebCryption